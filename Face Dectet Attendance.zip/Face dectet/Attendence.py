import datetime
import os
clear=lambda: os.system("cls")
tday=datetime.date.today()
"""print("DATE:")
print(tday)"""
def collector():
    clear()
    import cv2
    import sqlite3
    import numpy as np
    faceDetect=cv2.CascadeClassifier('haarcascade_frontalface_default.xml');
    cam=cv2.VideoCapture(0);

    def insertOrUpdate(Id,Name):
        conn=sqlite3.connect("Facebase.db")
        cmd="SELECT * FROM Student WHERE ID="+str(Id)
        curser=conn.execute(cmd)
        isRecordExist=0
        for row in curser:
            isRecordExist=1
        if(isRecordExist>=1):
            cmd="UPDATE Student SET Name="+str(Name)+"WHERE ID="+str(Id)
        else:
            cmd="INSERT INTO Student(ID,Name) Values("+str(Id)+","+str(Name)+")"
        conn.execute(cmd)
        conn.commit()
        conn.close()
        
    id=raw_input('Enter Student ID:')
    name=raw_input('Enter Student Name:')
    insertOrUpdate(id,name)
    sampleNum=0;
    while(True):
        ret,img=cam.read();
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        face=faceDetect.detectMultiScale(gray,1.3,5);
        for(x,y,w,h) in face:
            sampleNum=sampleNum+1
            cv2.imwrite("Studentimg/"+str("Name")+"."+str(id)+"."+str(sampleNum)+".jpg",gray[y:y+h,x:x+w])
            cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
            cv2.waitKey(100);
        cv2.imshow("Face",img);
        cv2.waitKey(1);
        if(sampleNum>2):
            break
    cam.release()
    cv2.destroyAllWindows()
    clear()
    print("Sucessfully Add Face For ID:" ,id)


def rec():
    clear()
    import os
    import cv2
    import numpy as np
    from PIL import Image

    recognizer=cv2.createLBPHFaceRecognizer();
    path='Studentimg'

    def getImagesWithID(path):
        imagepaths=[os.path.join(path,f)for f in os.listdir(path)]
        faces=[]
        IDs=[]
        for imagePath in imagepaths:
            faceImg=Image.open(imagePath).convert('L');
            faceNp=np.array(faceImg,'uint8')
            ID=int(os.path.split(imagePath)[-1].split('.')[1])
            faces.append(faceNp)
            IDs.append(ID)
            cv2.imshow("training",faceNp)
            cv2.waitKey(10)
        return np.array(IDs),faces
    Ids,faces=getImagesWithID(path)
    recognizer.train(faces,Ids)
    recognizer.save('recognizer/trainningData.yml')
    cv2.destroyAllWindows()
    import os
    import cv2
    import numpy as np
    from PIL import Image

    recognizer=cv2.createLBPHFaceRecognizer();
    path='Studentimg'

    def getImagesWithID(path):
        imagepaths=[os.path.join(path,f)for f in os.listdir(path)]
        print imagepaths

    getImagesWithID(path)
    clear()
    print("Sucessfuly Save Faces Into Database...!")

def dectetor():
    clear()
    import cv2
    import numpy as np
    import sqlite3
    faceDetect=cv2.CascadeClassifier('haarcascade_frontalface_default.xml');
    dt=raw_input('Enter Date As "DATE/MONTH" :')
    def insert(Id):
        conn=sqlite3.connect("Facebase.db")
        cmd="SELECT ID FROM Student WHERE ID="+str(Id)
        curser=conn.execute(cmd)
        isRecordExist1=0
        for row in curser:
            cmd="INSERT INTO Attendence(ID,DATE) Values("+str(Id)+","+str(dt)+")"
        conn.execute(cmd)
        conn.commit()
        conn.close()
    cam=cv2.VideoCapture(0);
    rec=cv2.createLBPHFaceRecognizer();
    rec.load("recognizer\\trainningData.yml")
    id=0
    font=cv2.cv.InitFont(cv2.cv.CV_FONT_HERSHEY_COMPLEX_SMALL,1,1,0,2)

    while(True):
        for i in range(80):
            ret,img=cam.read();
            gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            face=faceDetect.detectMultiScale(gray,1.3,5);
            for(x,y,w,h) in face:
                cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
                id,conf=rec.predict(gray[y:y+h,x:x+w])
                if(id==0):
                    id="Unknown"

                cv2.cv.PutText(cv2.cv.fromarray(img),str(id),(x,y+h),font,255);
                insert(id)
                cv2.imshow("Face",img);
                if(cv2.waitKey(1)==ord('q')):
                    break;
        cam.release()
        cv2.destroyAllWindows()
        break;
    clear()
    print("Attendance Done...!")
    clear()
    
    import datetime
    import sqlite3
    tday=datetime.date.today()
    conn=sqlite3.connect("Facebase.db")
    cur=conn.cursor()
    cur.execute("SELECT distinct ID FROM Attendence WHERE DATE="+str(dt))
    print("Showing Attendance:");print(tday)
    print("ID")
    for i in cur.fetchall():
        print i[0]

def view():
    clear()
    import sqlite3
    date=textentry.get()
    conn=sqlite3.connect("Facebase.db")
    cur=conn.cursor()
    cur.execute("SELECT distinct ID FROM Attendence WHERE DATE="+str(date))
    print("ID")
    for i in cur.fetchall():
        print i[0]


def viewmnt():
    clear()
    import sqlite3
    conn=sqlite3.connect("Facebase.db")
    cur=conn.cursor()
    cur.execute("SELECT distinct ID, DATE FROM Attendence order by DATE")
    print("ID       DATE")
    for i in cur.fetchall():
        print i[0],'----', i[1]


from Tkinter import *

window=Tk()
window.title("Attendence System by Face Detection")

btn1=Button(window,text="ADD FACE",width=14, command=collector)
btn1.grid(row=0,column=0)
btn1.pack()
btn2=Button(window,text="SAVE FACE",width=14, command=rec)
btn2.grid(row=0,column=2)
btn2.pack()
btn3=Button(window,text="ATTENDENCE",width=14, command=dectetor)
btn3.grid(row=1,column=0)
btn3.pack()
canvas=Canvas(window, width=500, height=400)
canvas.pack()
my_image= PhotoImage(file='C:\\Users\Akibur_Rahman\Desktop\Face dectet\\me.gif')
canvas.create_image(0,0, anchor = NW, image=my_image)

li=Label(window, text='ENTER THE DATE AS "DATE/MONTH" FOR YOU WANT TO SHOW ATTENDANCE:')
li.grid(row=0,column=0,sticky=W)
li.pack()
textentry=Entry(window, width=20, bg="white")
textentry.grid(row=2, column=0, sticky=W)
textentry.pack()
btn=Button(window,text="SEARCH",width=14, command=view)
btn.pack()

btn0=Button(window,text="ALL ATTENDANCE",width=14, command=viewmnt)
btn0.pack()

window.mainloop()
